| Épicos | Features | US   | Descrição                                                                                            |
|--------|----------|------|------------------------------------------------------------------------------------------------------|
| EP01   | FT01     | US1  | Eu, como usuário, quero visualizar a descrição do UnBoard                                            |
| EP01   | FT02     | US2  | Eu, como usuário, quero visualizar os dashboards                                                     |
| EP01   | FT03     | US3  | Eu, como usuário, quero visualizar a diferença de demanda de vagas por curso                         |
| EP01   | FT04     | US4  | Eu, como usuário, quero visualizar quais os cursos mais concorridos                                  |
| EP01   | FT05     | US5  | Eu, como usuário, quero visualizar quais os cursos menos concorridos                                 |
| EP01   | FT06     | US6  | Eu, como usuário, quero visualizar a concorrência do mesmo curso quanto a licenciatura e bacharelado |
| EP01   | FT07     | US7  | Eu, como usuário, quero visualizar a concorrência do mesmo curso quanto à diurno e noturno           |
| EP01   | FT08     | US8  | Eu, como usuário, quero visualizar quais os cursos com mais vagas                                    |
| EP01   | FT09     | US9  | Eu, como usuário, quero visualizar quais os cursos com menos vagas                                   |
| EP01   | FT10     | US10 | Eu, como usuário, quero pesquisar as informações de determinado curso                                |
| EP01   | FT11     | US11 | Como interessado, quero visualizar as estatísticas entre diruno/noturno                              |
| EP01   | FT12     | US12 | Eu, como usuário, quero visualizar a descrição dos membros do UnBoard                                |
