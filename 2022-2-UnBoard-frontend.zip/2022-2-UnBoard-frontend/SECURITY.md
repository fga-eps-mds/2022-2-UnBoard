# Security Policy

## Versões suportadas

| Version | Supported          |
| ------- | ------------------ |
| 0.1   | On construction 👷‍♂️ |

## Reportando bugs

Se achar um bug, vá na aba issues, abra uma issue com um [template bug-report]() e siga as instruções lá ditas.
