import pandas as pd

df = pd.read_excel("../../pdfs/VESTUNB_23.xlsx")

global Nome
global Vazia

Nome = "Direito (Bacharelado)" #nome que deseja pesquisar
Vazia = "Unnamed: 0" #nome da coluna vazia